extends CharacterBody2D

var is_dragging: bool = false
var mouse_offset: Vector2 = Vector2.ZERO

@onready var globalcamera: Camera2D = %globalcam
@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

@export var gravity: float = 980.0
@export var friction: float = 2.0

func _physics_process(delta: float) -> void:
	if is_dragging:
		globalcamera.position = self.position
		
		# 1. Calculamos dónde debería estar el personaje
		var target_position = get_global_mouse_position() - mouse_offset
		
		# 2. Asignamos la velocidad requerida para llegar a ese punto en este frame
		velocity = (target_position - global_position) / delta
	else:
		globalcamera.position.x = 0
		globalcamera.position.y = 0
		
	move_and_slide()

func _input_event(_viewport: Viewport, event: InputEvent, _shape_idx: int) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.is_pressed():
			is_dragging = true
			mouse_offset = get_global_mouse_position() - global_position
			velocity = Vector2.ZERO

func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.is_released():
			if is_dragging:
				is_dragging = false
				# Limitar la velocidad de lanzamiento para evitar bugs físicos
				velocity = velocity.limit_length(1500)

func _ready() -> void:
	globalcamera.position_smoothing_enabled = true
