class_name GameManager
extends Node

@onready var hud: Control = %HUD

var points = 0
var mult   = 1

func add_points(pts: int) -> void:
	points += pts
	hud.update_points()
