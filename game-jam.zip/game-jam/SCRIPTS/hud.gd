extends Control

@onready var points: Label = $CanvasLayer/points
@onready var game: GameManager = %"Game manager"

func update_points():
	points.text = str(game.points)
